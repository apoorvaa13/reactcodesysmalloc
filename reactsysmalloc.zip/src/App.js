import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import BookmarksPage from "./pages/BookmarksPage";
import AskQuestionPage from "./pages/AskQuestionPage";
import ParticularQuestionPageAfter from "./pages/ParticularQuestionPageAfter";
import ParticularQuestionPageAfter1 from "./pages/ParticularQuestionPageAfter1";
import ParticularQuestionPage from "./pages/ParticularQuestionPage";
import UserPagefromAllUsersPage from "./pages/UserPagefromAllUsersPage";
import UserPagefromAllUsersPage1 from "./pages/UserPagefromAllUsersPage1";
import FeedPage from "./pages/FeedPage";
import FollowersPage from "./pages/FollowersPage";
import FollowingPage from "./pages/FollowingPage";
import LoginPage from "./pages/LoginPage";
import SignUpPage from "./pages/SignUpPage";
import UsersPage from "./pages/UsersPage";
import EditProfilePage from "./pages/EditProfilePage";
import AllUsersPage from "./pages/AllUsersPage";
import UserProfilePage from "./pages/UserProfilePage";
import AllQuestionsPage from "./pages/AllQuestionsPage";
import FrameComponent from "./pages/FrameComponent";
import ParticularQuestionPageNotA from "./pages/ParticularQuestionPageNotA";
import BookmarkedPage from "./pages/BookmarkedPage";
import { useEffect } from "react";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/ask-question-page":
        title = "";
        metaDescription = "";
        break;
      case "/particular-question-pageafter-downvoting":
        title = "";
        metaDescription = "";
        break;
      case "/particular-question-pageafter-upvoting":
        title = "";
        metaDescription = "";
        break;
      case "/particular-question-page":
        title = "";
        metaDescription = "";
        break;
      case "/user-pagefrom-all-users-pageafter-following":
        title = "";
        metaDescription = "";
        break;
      case "/user-pagefrom-all-users-pagebefore-following":
        title = "";
        metaDescription = "";
        break;
      case "/feed-page":
        title = "";
        metaDescription = "";
        break;
      case "/followers-page":
        title = "";
        metaDescription = "";
        break;
      case "/following-page":
        title = "";
        metaDescription = "";
        break;
      case "/login-page":
        title = "";
        metaDescription = "";
        break;
      case "/signup-page":
        title = "";
        metaDescription = "";
        break;
      case "/users-page":
        title = "";
        metaDescription = "";
        break;
      case "/edit-profile-page":
        title = "";
        metaDescription = "";
        break;
      case "/all-users-page":
        title = "";
        metaDescription = "";
        break;
      case "/user-profile-page":
        title = "";
        metaDescription = "";
        break;
      case "/all-questions-page":
        title = "";
        metaDescription = "";
        break;
      case "/frame-35":
        title = "";
        metaDescription = "";
        break;
      case "/particular-question-pagenot-answered":
        title = "";
        metaDescription = "";
        break;
      case "/bookmarked-page":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<BookmarksPage />} />
      <Route path="/ask-question-page" element={<AskQuestionPage />} />
      <Route
        path="/particular-question-pageafter-downvoting"
        element={<ParticularQuestionPageAfter />}
      />
      <Route
        path="/particular-question-pageafter-upvoting"
        element={<ParticularQuestionPageAfter1 />}
      />
      <Route
        path="/particular-question-page"
        element={<ParticularQuestionPage />}
      />
      <Route
        path="/user-pagefrom-all-users-pageafter-following"
        element={<UserPagefromAllUsersPage />}
      />
      <Route
        path="/user-pagefrom-all-users-pagebefore-following"
        element={<UserPagefromAllUsersPage1 />}
      />
      <Route path="/feed-page" element={<FeedPage />} />
      <Route path="/followers-page" element={<FollowersPage />} />
      <Route path="/following-page" element={<FollowingPage />} />
      <Route path="/login-page" element={<LoginPage />} />
      <Route path="/signup-page" element={<SignUpPage />} />
      <Route path="/users-page" element={<UsersPage />} />
      <Route path="/edit-profile-page" element={<EditProfilePage />} />
      <Route path="/all-users-page" element={<AllUsersPage />} />
      <Route path="/user-profile-page" element={<UserProfilePage />} />
      <Route path="/all-questions-page" element={<AllQuestionsPage />} />
      <Route path="/frame-35" element={<FrameComponent />} />
      <Route
        path="/particular-question-pagenot-answered"
        element={<ParticularQuestionPageNotA />}
      />
      <Route path="/bookmarked-page" element={<BookmarkedPage />} />
    </Routes>
  );
}
export default App;
