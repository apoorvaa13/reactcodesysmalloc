import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./SignUpPage.module.css";

const SignUpPage = () => {
  const navigate = useNavigate();

  const onRectangle1Click = useCallback(() => {
    navigate("/users-page");
  }, [navigate]);

  const onFrameContainer5Click = useCallback(() => {
    // Please sync "Home Page" to the project
  }, []);

  const onRectangleButtonClick = useCallback(() => {
    // Please sync "Home Page" to the project
  }, []);

  return (
    <div className={styles.signupPage}>
      <div className={styles.frameParent}>
        <div className={styles.frameGroup}>
          <div className={styles.iconFacebookV1Parent}>
            <img
              className={styles.iconFacebookV1}
              alt=""
              src="/-icon-facebook-v12.svg"
            />
            <img
              className={styles.iconTwitter}
              alt=""
              src="/-icon-twitter5.svg"
            />
            <img
              className={styles.iconInstagram}
              alt=""
              src="/-icon-instagram.svg"
            />
            <img
              className={styles.iconLinkedin}
              alt=""
              src="/-icon-linkedin.svg"
            />
          </div>
          <div className={styles.siteDesignlogo}>
            site design/logo © 2023 #FFFFFF
          </div>
        </div>
        <div className={styles.sysmalloc}>SysMalloc</div>
        <img
          className={styles.screenshot202302241556231Icon}
          alt=""
          src="/screenshot-20230224-155623-1@2x.png"
        />
      </div>
      <div className={styles.vectorParent}>
        <img className={styles.vectorIcon} alt="" src="/vector3.svg" />
        <img className={styles.vectorIcon1} alt="" src="/vector4.svg" />
        <img className={styles.vectorIcon2} alt="" src="/vector5.svg" />
        <img className={styles.vectorIcon3} alt="" src="/vector6.svg" />
        <img className={styles.vectorIcon4} alt="" src="/vector7.svg" />
        <img className={styles.vectorIcon5} alt="" src="/vector8.svg" />
        <img className={styles.vectorIcon6} alt="" src="/vector9.svg" />
        <div className={styles.byteIntoThe}>Byte into the future !</div>
        <div className={styles.cntrlaltdelight}>Cntrl+Alt+Delight</div>
        <img className={styles.imageIcon} alt="" src="/image@2x.png" />
      </div>
      <div className={styles.signupPageChild} />
      <div className={styles.rectangleParent}>
        <input className={styles.frameChild} type="text" />
        <input className={styles.frameItem} type="text" />
        <div className={styles.emailId}>Email Id</div>
        <div className={styles.password}>Password</div>
        <div className={styles.fullName}>Full name</div>
        <div className={styles.displayName}>Display name</div>
        <div className={styles.signUp}>Sign Up</div>
        <input className={styles.frameInner} type="text" />
        <input className={styles.rectangleInput} type="text" />
        <img
          className={styles.logosrecaptchaIcon}
          alt=""
          src="/logosrecaptcha1.svg"
        />
        <div className={styles.rectangleGroup}>
          <div className={styles.rectangleDiv} onClick={onRectangle1Click} />
          <button className={styles.cancel}>Sign Up</button>
        </div>
        <div
          className={styles.rectangleContainer}
          onClick={onFrameContainer5Click}
        >
          <button
            className={styles.rectangleButton}
            onClick={onRectangleButtonClick}
          />
          <button className={styles.cancel}>Cancel</button>
        </div>
        <input className={styles.frameChild1} type="text" />
      </div>
      <img className={styles.image5Icon} alt="" src="/image-5@2x.png" />
      <div className={styles.sysmallocParent}>
        <div className={styles.sysmalloc1}>SysMalloc</div>
        <div className={styles.frameWrapper}>
          <div className={styles.mdiLightmagnifyParent}>
            <img
              className={styles.mdiLightmagnifyIcon}
              alt=""
              src="/mdilightmagnify.svg"
            />
            <div className={styles.search}>search</div>
          </div>
        </div>
        <div className={styles.logInParent}>
          <div className={styles.search}>Log In</div>
          <div className={styles.search}> Sign Up</div>
        </div>
        <img
          className={styles.screenshot202302241556232Icon}
          alt=""
          src="/screenshot202302241556232@3x.png"
        />
      </div>
    </div>
  );
};

export default SignUpPage;
