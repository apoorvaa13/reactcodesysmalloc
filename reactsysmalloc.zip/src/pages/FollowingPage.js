import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./FollowingPage.module.css";

const FollowingPage = () => {
  const navigate = useNavigate();

  const onQuestionsClick = useCallback(() => {
    navigate("/all-questions-page");
  }, [navigate]);

  const onUsersClick = useCallback(() => {
    navigate("/all-users-page");
  }, [navigate]);

  const onRectangleClick = useCallback(() => {
    navigate("/followers-page");
  }, [navigate]);

  const onRectangle2Click = useCallback(() => {
    navigate("/feed-page");
  }, [navigate]);

  const onRectangle3Click = useCallback(() => {
    navigate("/edit-profile-page");
  }, [navigate]);

  const onRectangle4Click = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const onSysMallocText1Click = useCallback(() => {
    navigate("/users-page");
  }, [navigate]);

  const onLogoutClick = useCallback(() => {
    // Please sync "Home Page" to the project
  }, []);

  const onScreenshot202302241556232Click = useCallback(() => {
    navigate("/users-page");
  }, [navigate]);

  const onUsernameClick = useCallback(() => {
    navigate("/user-profile-page");
  }, [navigate]);

  return (
    <div className={styles.followingPage}>
      <div className={styles.frameParent}>
        <div className={styles.frameGroup}>
          <div className={styles.iconFacebookV1Parent}>
            <img
              className={styles.iconFacebookV1}
              alt=""
              src="/-icon-facebook-v1.svg"
            />
            <img
              className={styles.iconTwitter}
              alt=""
              src="/-icon-twitter.svg"
            />
            <img
              className={styles.iconInstagram}
              alt=""
              src="/-icon-instagram.svg"
            />
            <img
              className={styles.iconLinkedin}
              alt=""
              src="/-icon-linkedin.svg"
            />
          </div>
          <div className={styles.siteDesignlogo}>
            site design/logo © 2023 #FFFFFF
          </div>
        </div>
        <div className={styles.sysmalloc}>SysMalloc</div>
        <img
          className={styles.screenshot202302241556231Icon}
          alt=""
          src="/screenshot-20230224-155623-1@2x.png"
        />
      </div>
      <div className={styles.questionsParent}>
        <button className={styles.questions} onClick={onQuestionsClick}>
          Questions
        </button>
        <button className={styles.users} onClick={onUsersClick}>
          Users
        </button>
      </div>
      <div className={styles.reputation0Parent}>
        <div className={styles.reputation0}>Reputation: 0</div>
        <div className={styles.username}>Username</div>
        <img className={styles.image1Icon} alt="" src="/image-1@2x.png" />
        <div className={styles.rectangleParent}>
          <div className={styles.frameChild} onClick={onRectangleClick} />
          <button className={styles.followers}>Followers</button>
        </div>
        <div className={styles.rectangleGroup}>
          <div className={styles.frameItem} />
          <button className={styles.following}>Following</button>
        </div>
        <div className={styles.rectangleContainer}>
          <div className={styles.frameInner} onClick={onRectangle2Click} />
          <button className={styles.feed}>Feed</button>
        </div>
        <div className={styles.frameDiv}>
          <div className={styles.rectangleDiv} onClick={onRectangle3Click} />
          <button className={styles.editProfile}>Edit Profile</button>
          <img className={styles.mdipencilIcon} alt="" src="/mdipencil.svg" />
        </div>
        <img className={styles.vectorIcon} alt="" src="/vector2.svg" />
        <div className={styles.rectangleParent1}>
          <div className={styles.frameChild1} onClick={onRectangle4Click} />
          <button className={styles.bookmarks}>Bookmarks</button>
        </div>
        <div className={styles.india}>India</div>
      </div>
      <div className={styles.frameContainer}>
        <button className={styles.image3Parent}>
          <img className={styles.image3Icon} alt="" src="/image-3@2x.png" />
          <div className={styles.gabriele}>Gabriele</div>
          <div className={styles.italy}>Italy</div>
          <div className={styles.div}>4,499</div>
        </button>
        <div className={styles.image3Group}>
          <img className={styles.image3Icon} alt="" src="/image-31@2x.png" />
          <div className={styles.tjCrowder}>T.J Crowder</div>
          <div className={styles.uk}>UK</div>
          <div className={styles.div1}>4,420</div>
        </div>
        <div className={styles.unmitigatedParent}>
          <div className={styles.tjCrowder}>Unmitigated</div>
          <div className={styles.usa}>USA</div>
          <div className={styles.div1}>4,183</div>
          <img className={styles.image4Icon} alt="" src="/image-4@2x.png" />
        </div>
        <div className={styles.shepmasterParent}>
          <div className={styles.tjCrowder}>Shepmaster</div>
          <div className={styles.usa}>Pittsburgh</div>
          <div className={styles.div1}>4,130</div>
          <img className={styles.image4Icon} alt="" src="/image-41@2x.png" />
        </div>
      </div>
      <div className={styles.frameParent1}>
        <div className={styles.image3Container}>
          <img className={styles.image3Icon} alt="" src="/image-32@2x.png" />
          <div className={styles.gregHewgill}>mklement0</div>
          <div className={styles.div4}>4,026</div>
        </div>
        <div className={styles.image3Group}>
          <img className={styles.image3Icon} alt="" src="/image-33@2x.png" />
          <div className={styles.tjCrowder}>chepner</div>
          <div className={styles.uk}>Massachusettes</div>
          <div className={styles.div1}>3,813</div>
        </div>
        <div className={styles.unmitigatedParent}>
          <div className={styles.tjCrowder}>unutbu</div>
          <div className={styles.usa}>Germany</div>
          <div className={styles.div1}>3,802</div>
          <img className={styles.image4Icon} alt="" src="/image-42@2x.png" />
        </div>
        <div className={styles.shepmasterParent}>
          <div className={styles.tjCrowder}>Guru Stron</div>
          <div className={styles.usa}>St. Petersburg</div>
          <div className={styles.div1}>3,780</div>
          <img className={styles.image4Icon} alt="" src="/image-43@2x.png" />
        </div>
      </div>
      <div className={styles.following1}>Following</div>
      <div className={styles.following2}>30 following</div>
      <div className={styles.frameParent2}>
        <div className={styles.image3Parent2}>
          <img className={styles.image3Icon} alt="" src="/image-34@2x.png" />
          <div className={styles.tjCrowder}>Frank van</div>
          <div className={styles.sanFrancisco}>San Francisco</div>
          <div className={styles.div1}>3,726</div>
        </div>
        <div className={styles.image3Group}>
          <img className={styles.image3Icon} alt="" src="/image-35@2x.png" />
          <div className={styles.tjCrowder}>Erwin Brandster</div>
          <div className={styles.uk}>Vienna, Austria</div>
          <div className={styles.div1}>3,704</div>
        </div>
        <div className={styles.gregHewgillParent}>
          <div className={styles.gregHewgill}>Greg Hewgill</div>
          <div className={styles.div4}>3,700</div>
          <img className={styles.image4Icon} alt="" src="/image-44@2x.png" />
        </div>
        <div className={styles.shepmasterParent}>
          <div className={styles.tjCrowder}>larsks</div>
          <div className={styles.usa}>Switzerland</div>
          <div className={styles.div1}>3,659</div>
          <img className={styles.image4Icon} alt="" src="/image-45@2x.png" />
        </div>
      </div>
      <div className={styles.sysmallocParent}>
        <div className={styles.sysmalloc1} onClick={onSysMallocText1Click}>
          SysMalloc
        </div>
        <input className={styles.frameInput} type="text" />
        <button className={styles.logout} onClick={onLogoutClick}>
          logout
        </button>
        <button
          className={styles.screenshot202302241556232}
          onClick={onScreenshot202302241556232Click}
        />
        <div className={styles.usernameParent}>
          <button className={styles.username1} onClick={onUsernameClick}>
            Username
          </button>
          <img className={styles.vectorIcon1} alt="" src="/vector.svg" />
        </div>
      </div>
    </div>
  );
};

export default FollowingPage;
