import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./ParticularQuestionPage.module.css";

const ParticularQuestionPage = () => {
  const navigate = useNavigate();

  const onQuestionsClick = useCallback(() => {
    navigate("/all-questions-page");
  }, [navigate]);

  const onUsersClick = useCallback(() => {
    navigate("/all-users-page");
  }, [navigate]);

  const onPhbookmarkSimpleClick = useCallback(() => {
    navigate("/bookmarked-page");
  }, [navigate]);

  const onRectangleClick = useCallback(() => {
    navigate("/ask-question-page");
  }, [navigate]);

  const onPolygonIconClick = useCallback(() => {
    navigate("/particular-question-pageafter-upvoting");
  }, [navigate]);

  const onPolygonIcon1Click = useCallback(() => {
    navigate("/particular-question-pageafter-downvoting");
  }, [navigate]);

  const onSysMallocText1Click = useCallback(() => {
    navigate("/users-page");
  }, [navigate]);

  const onLogoutClick = useCallback(() => {
    // Please sync "Home Page" to the project
  }, []);

  const onScreenshot202302241556232Click = useCallback(() => {
    navigate("/users-page");
  }, [navigate]);

  const onUsernameClick = useCallback(() => {
    navigate("/user-profile-page");
  }, [navigate]);

  return (
    <div className={styles.particularQuestionPage}>
      <div className={styles.frameParent}>
        <div className={styles.frameGroup}>
          <div className={styles.iconFacebookV1Parent}>
            <img
              className={styles.iconFacebookV1}
              alt=""
              src="/-icon-facebook-v1.svg"
            />
            <img
              className={styles.iconTwitter}
              alt=""
              src="/-icon-twitter2.svg"
            />
            <img
              className={styles.iconInstagram}
              alt=""
              src="/-icon-instagram1.svg"
            />
            <img
              className={styles.iconLinkedin}
              alt=""
              src="/-icon-linkedin1.svg"
            />
          </div>
          <div className={styles.siteDesignlogo}>
            site design/logo © 2023 #FFFFFF
          </div>
        </div>
        <div className={styles.sysmalloc}>SysMalloc</div>
        <img
          className={styles.screenshot202302241556231Icon}
          alt=""
          src="/screenshot-20230224-155623-1@2x.png"
        />
      </div>
      <div className={styles.questionsParent}>
        <button className={styles.questions} onClick={onQuestionsClick}>
          Questions
        </button>
        <button className={styles.users} onClick={onUsersClick}>
          Users
        </button>
      </div>
      <img
        className={styles.phbookmarkSimpleIcon}
        alt=""
        src="/phbookmarksimple.svg"
        onClick={onPhbookmarkSimpleClick}
      />
      <div className={styles.howToGetMongodbCollectionParent}>
        <div className={styles.howToGet}>
          How to get Mongodb collection data from a table in MySql
        </div>
        <div className={styles.rectangleParent}>
          <div className={styles.frameChild} onClick={onRectangleClick} />
          <button className={styles.askQuestion}>Ask Question</button>
        </div>
      </div>
      <img className={styles.image6Icon} alt="" src="/image-6@2x.png" />
      <img
        className={styles.particularQuestionPageChild}
        alt=""
        src="/polygon-1.svg"
        onClick={onPolygonIconClick}
      />
      <img
        className={styles.particularQuestionPageItem}
        alt=""
        src="/polygon-2.svg"
        onClick={onPolygonIcon1Click}
      />
      <div className={styles.div}>1</div>
      <div className={styles.sysmallocParent}>
        <div className={styles.sysmalloc1} onClick={onSysMallocText1Click}>
          SysMalloc
        </div>
        <input className={styles.frameItem} type="text" />
        <button className={styles.logout} onClick={onLogoutClick}>
          logout
        </button>
        <button
          className={styles.screenshot202302241556232}
          onClick={onScreenshot202302241556232Click}
        />
        <div className={styles.usernameParent}>
          <button className={styles.username} onClick={onUsernameClick}>
            Username
          </button>
          <img className={styles.vectorIcon} alt="" src="/vector.svg" />
        </div>
      </div>
    </div>
  );
};

export default ParticularQuestionPage;
