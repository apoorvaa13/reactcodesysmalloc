import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./UserProfilePage.module.css";

const UserProfilePage = () => {
  const navigate = useNavigate();

  const onQuestionsClick = useCallback(() => {
    navigate("/all-questions-page");
  }, [navigate]);

  const onUsersClick = useCallback(() => {
    navigate("/all-users-page");
  }, [navigate]);

  const onRectangle2Click = useCallback(() => {
    navigate("/edit-profile-page");
  }, [navigate]);

  const onRectangle3Click = useCallback(() => {
    navigate("/followers-page");
  }, [navigate]);

  const onRectangle4Click = useCallback(() => {
    navigate("/feed-page");
  }, [navigate]);

  const onRectangle5Click = useCallback(() => {
    navigate("/following-page");
  }, [navigate]);

  const onRectangleButton4Click = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const onSysMallocText1Click = useCallback(() => {
    navigate("/users-page");
  }, [navigate]);

  const onLogoutClick = useCallback(() => {
    // Please sync "Home Page" to the project
  }, []);

  const onScreenshot202302241556232Click = useCallback(() => {
    navigate("/users-page");
  }, [navigate]);

  const onUsernameClick = useCallback(() => {
    navigate("/user-profile-page");
  }, [navigate]);

  return (
    <div className={styles.userProfilePage}>
      <div className={styles.frameParent}>
        <div className={styles.frameGroup}>
          <div className={styles.iconFacebookV1Parent}>
            <img
              className={styles.iconFacebookV1}
              alt=""
              src="/-icon-facebook-v1.svg"
            />
            <img
              className={styles.iconTwitter}
              alt=""
              src="/-icon-twitter.svg"
            />
            <img
              className={styles.iconInstagram}
              alt=""
              src="/-icon-instagram.svg"
            />
            <img
              className={styles.iconLinkedin}
              alt=""
              src="/-icon-linkedin.svg"
            />
          </div>
          <div className={styles.siteDesignlogo}>
            site design/logo © 2023 #FFFFFF
          </div>
        </div>
        <div className={styles.sysmalloc}>SysMalloc</div>
        <img
          className={styles.screenshot202302241556231Icon}
          alt=""
          src="/screenshot-20230224-155623-1@2x.png"
        />
      </div>
      <div className={styles.questionsParent}>
        <button className={styles.questions} onClick={onQuestionsClick}>
          Questions
        </button>
        <button className={styles.users} onClick={onUsersClick}>
          Users
        </button>
      </div>
      <div className={styles.rectangleParent}>
        <div className={styles.frameChild} />
        <div className={styles.youHaveNot}>
          You have not asked any questions
        </div>
        <div className={styles.questions1}>Questions</div>
        <div className={styles.rectangleGroup}>
          <button className={styles.frameItem} />
          <button className={styles.frameInner} />
          <button className={styles.newest}>Newest</button>
          <button className={styles.score}>Score</button>
        </div>
      </div>
      <div className={styles.rectangleContainer}>
        <div className={styles.rectangleDiv} />
        <div className={styles.youHaveNot1}>
          You have not answered any questions
        </div>
        <div className={styles.frameDiv}>
          <button className={styles.frameItem} />
          <button className={styles.frameInner} />
          <button className={styles.newest}>Newest</button>
          <button className={styles.score}>Score</button>
        </div>
        <div className={styles.answers}>Answers</div>
      </div>
      <div className={styles.reputation0Parent}>
        <div className={styles.reputation0}>Reputation: 0</div>
        <div className={styles.india}>India</div>
        <div className={styles.username}>Username</div>
        <img className={styles.image1Icon} alt="" src="/image-1@2x.png" />
        <div className={styles.rectangleParent1}>
          <div className={styles.frameChild2} onClick={onRectangle2Click} />
          <button className={styles.editProfile}>Edit Profile</button>
          <img className={styles.mdipencilIcon} alt="" src="/mdipencil1.svg" />
        </div>
        <div className={styles.rectangleParent2}>
          <div className={styles.frameChild3} onClick={onRectangle3Click} />
          <button className={styles.followers}>Followers</button>
          <div className={styles.rectangleParent3}>
            <div className={styles.frameChild4} onClick={onRectangle4Click} />
            <button className={styles.feed}>Feed</button>
          </div>
          <div className={styles.rectangleParent4}>
            <div className={styles.frameChild5} onClick={onRectangle5Click} />
            <button className={styles.following}>Following</button>
          </div>
        </div>
        <div className={styles.frameChild6} />
        <div className={styles.rectangleParent5}>
          <button
            className={styles.frameChild7}
            onClick={onRectangleButton4Click}
          />
          <button className={styles.bookmarks}>Bookmarks</button>
        </div>
      </div>
      <div className={styles.statsParent}>
        <div className={styles.stats}>Stats</div>
        <div className={styles.rectangleParent6}>
          <div className={styles.frameChild8} />
          <div className={styles.div}>30</div>
          <div className={styles.div1}>20</div>
          <div className={styles.following1}>Following:</div>
          <div className={styles.followers1}>{`Followers: `}</div>
          <div className={styles.upvotes}>{`Upvotes: `}</div>
          <div className={styles.div2}>0</div>
          <div className={styles.div3}>0</div>
          <div className={styles.div4}>0</div>
          <div className={styles.div5}>0</div>
          <div className={styles.answers1}>Answers:</div>
          <div className={styles.downvotes}>Downvotes:</div>
          <div className={styles.questions2}>{`Questions: `}</div>
        </div>
      </div>
      <img className={styles.vectorIcon} alt="" src="/vector10.svg" />
      <div className={styles.sysmallocParent}>
        <div className={styles.sysmalloc1} onClick={onSysMallocText1Click}>
          SysMalloc
        </div>
        <input className={styles.frameInput} type="text" />
        <button className={styles.logout} onClick={onLogoutClick}>
          logout
        </button>
        <button
          className={styles.screenshot202302241556232}
          onClick={onScreenshot202302241556232Click}
        />
        <div className={styles.usernameParent}>
          <button className={styles.username1} onClick={onUsernameClick}>
            Username
          </button>
          <img className={styles.vectorIcon1} alt="" src="/vector.svg" />
        </div>
      </div>
    </div>
  );
};

export default UserProfilePage;
