import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./AllUsersPage.module.css";

const AllUsersPage = () => {
  const navigate = useNavigate();

  const onQuestionsClick = useCallback(() => {
    navigate("/all-questions-page");
  }, [navigate]);

  const onMozwayTextClick = useCallback(() => {
    navigate("/user-pagefrom-all-users-pagebefore-following");
  }, [navigate]);

  const onSysMallocText1Click = useCallback(() => {
    navigate("/users-page");
  }, [navigate]);

  const onLogoutClick = useCallback(() => {
    // Please sync "Home Page" to the project
  }, []);

  const onScreenshot202302241556232ImageClick = useCallback(() => {
    navigate("/users-page");
  }, [navigate]);

  const onUsernameClick = useCallback(() => {
    navigate("/user-profile-page");
  }, [navigate]);

  return (
    <div className={styles.allUsersPage}>
      <div className={styles.frameParent}>
        <div className={styles.frameGroup}>
          <div className={styles.iconFacebookV1Parent}>
            <img
              className={styles.iconFacebookV1}
              alt=""
              src="/-icon-facebook-v1.svg"
            />
            <img
              className={styles.iconTwitter}
              alt=""
              src="/-icon-twitter4.svg"
            />
            <img
              className={styles.iconInstagram}
              alt=""
              src="/-icon-instagram.svg"
            />
            <img
              className={styles.iconLinkedin}
              alt=""
              src="/-icon-linkedin.svg"
            />
          </div>
          <div className={styles.siteDesignlogo}>
            site design/logo © 2023 #FFFFFF
          </div>
        </div>
        <div className={styles.sysmalloc}>SysMalloc</div>
        <img
          className={styles.screenshot202302241556231Icon}
          alt=""
          src="/screenshot-20230224-155623-1@2x.png"
        />
      </div>
      <div className={styles.questionsParent}>
        <button className={styles.questions} onClick={onQuestionsClick}>
          Questions
        </button>
        <button className={styles.users}>Users</button>
      </div>
      <div className={styles.frameContainer}>
        <button className={styles.image3Parent}>
          <img className={styles.image3Icon} alt="" src="/image-36@2x.png" />
          <div className={styles.mozway} onClick={onMozwayTextClick}>
            mozway
          </div>
          <div className={styles.mareTranquillitatis}>Mare Tranquillitatis</div>
          <div className={styles.div}>6,776</div>
        </button>
        <div className={styles.image3Group}>
          <img className={styles.image3Icon} alt="" src="/image-37@2x.png" />
          <div className={styles.vonc}>VonC</div>
          <div className={styles.france}>France</div>
          <div className={styles.div1}>6,677</div>
        </div>
        <div className={styles.akrunParent}>
          <div className={styles.vonc}>akrun</div>
          <div className={styles.germany}>Germany</div>
          <div className={styles.div1}>6,116</div>
          <img className={styles.image4Icon} alt="" src="/image-46@2x.png" />
        </div>
        <div className={styles.jezraelParent}>
          <div className={styles.vonc}>Jezrael</div>
          <div className={styles.germany}>Slovakia</div>
          <div className={styles.div1}>5,624</div>
          <img className={styles.image4Icon} alt="" src="/image-47@2x.png" />
        </div>
      </div>
      <div className={styles.frameDiv}>
        <div className={styles.image3Container}>
          <img className={styles.image3Icon} alt="" src="/image-38@2x.png" />
          <div className={styles.vonc}>corralien</div>
          <div className={styles.germany}>USA</div>
          <div className={styles.div1}>5091</div>
        </div>
        <div className={styles.image3Group}>
          <img className={styles.image3Icon} alt="" src="/image-39@2x.png" />
          <div className={styles.vonc}>jcalz</div>
          <div className={styles.france}>USA</div>
          <div className={styles.div1}>4,904</div>
        </div>
        <div className={styles.jonSkeetParent}>
          <div className={styles.jonSkeet}>Jon skeet</div>
          <div className={styles.div6}>4,866</div>
          <img className={styles.image4Icon} alt="" src="/image-48@2x.png" />
        </div>
        <div className={styles.jezraelParent}>
          <div className={styles.vonc}>Martijin Pieters</div>
          <div className={styles.germany}>Cambridge, UK</div>
          <div className={styles.div1}>4,659</div>
          <img className={styles.image4Icon} alt="" src="/image-49@2x.png" />
        </div>
      </div>
      <div className={styles.frameParent1}>
        <div className={styles.image3Container}>
          <img className={styles.image3Icon} alt="" src="/image-3@2x.png" />
          <div className={styles.vonc}>Gabriele</div>
          <div className={styles.germany}>Italy</div>
          <div className={styles.div1}>4,499</div>
        </div>
        <div className={styles.image3Group}>
          <img className={styles.image3Icon} alt="" src="/image-31@2x.png" />
          <div className={styles.vonc}>T.J Crowder</div>
          <div className={styles.france}>UK</div>
          <div className={styles.div1}>4,420</div>
        </div>
        <div className={styles.akrunParent}>
          <div className={styles.vonc}>Unmitigated</div>
          <div className={styles.germany}>USA</div>
          <div className={styles.div1}>4,183</div>
          <img className={styles.image4Icon} alt="" src="/image-4@2x.png" />
        </div>
        <div className={styles.jezraelParent}>
          <div className={styles.vonc}>Shepmaster</div>
          <div className={styles.germany}>Pittsburgh</div>
          <div className={styles.div1}>4,130</div>
          <img className={styles.image4Icon} alt="" src="/image-41@2x.png" />
        </div>
      </div>
      <div className={styles.frameParent2}>
        <div className={styles.image3Parent4}>
          <img className={styles.image3Icon} alt="" src="/image-32@2x.png" />
          <div className={styles.jonSkeet}>mklement0</div>
          <div className={styles.div6}>4,026</div>
        </div>
        <div className={styles.image3Group}>
          <img className={styles.image3Icon} alt="" src="/image-33@2x.png" />
          <div className={styles.vonc}>chepner</div>
          <div className={styles.france}>Massachusettes</div>
          <div className={styles.div1}>3,813</div>
        </div>
        <div className={styles.akrunParent}>
          <div className={styles.vonc}>unutbu</div>
          <div className={styles.germany}>Germany</div>
          <div className={styles.div1}>3,802</div>
          <img className={styles.image4Icon} alt="" src="/image-42@2x.png" />
        </div>
        <div className={styles.jezraelParent}>
          <div className={styles.vonc}>Guru Stron</div>
          <div className={styles.germany}>St. Petersburg</div>
          <div className={styles.div1}>3,780</div>
          <img className={styles.image4Icon} alt="" src="/image-43@2x.png" />
        </div>
      </div>
      <div className={styles.frameParent3}>
        <div className={styles.image3Container}>
          <img className={styles.image3Icon} alt="" src="/image-34@2x.png" />
          <div className={styles.vonc}>Frank van</div>
          <div className={styles.sanFrancisco}>San Francisco</div>
          <div className={styles.div1}>3,726</div>
        </div>
        <div className={styles.image3Group}>
          <img className={styles.image3Icon} alt="" src="/image-35@2x.png" />
          <div className={styles.vonc}>Erwin Brandster</div>
          <div className={styles.france}>Vienna, Austria</div>
          <div className={styles.div1}>3,704</div>
        </div>
        <div className={styles.jonSkeetParent}>
          <div className={styles.jonSkeet}>Greg Hewgill</div>
          <div className={styles.div6}>3,700</div>
          <img className={styles.image4Icon} alt="" src="/image-44@2x.png" />
        </div>
        <div className={styles.jezraelParent}>
          <div className={styles.vonc}>larsks</div>
          <div className={styles.germany}>Switzerland</div>
          <div className={styles.div1}>3,659</div>
          <img className={styles.image4Icon} alt="" src="/image-45@2x.png" />
        </div>
      </div>
      <div className={styles.users1}>Users</div>
      <textarea className={styles.allUsersPageChild} required />
      <div className={styles.searchByUser}>search by user</div>
      <img
        className={styles.mdiLightmagnifyIcon}
        alt=""
        src="/mdilightmagnify.svg"
      />
      <div className={styles.sysmallocParent}>
        <div className={styles.sysmalloc1} onClick={onSysMallocText1Click}>
          SysMalloc
        </div>
        <input className={styles.frameChild} type="text" />
        <button className={styles.logout} onClick={onLogoutClick}>
          logout
        </button>
        <img
          className={styles.screenshot202302241556232Icon}
          alt=""
          src="/screenshot202302241556232@3x.png"
          onClick={onScreenshot202302241556232ImageClick}
        />
        <div className={styles.usernameParent}>
          <button className={styles.username} onClick={onUsernameClick}>
            Username
          </button>
          <img className={styles.vectorIcon} alt="" src="/vector.svg" />
        </div>
      </div>
    </div>
  );
};

export default AllUsersPage;
