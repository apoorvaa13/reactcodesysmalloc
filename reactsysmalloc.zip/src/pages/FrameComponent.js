import styles from "./FrameComponent.module.css";

const FrameComponent = () => {
  return <div className={styles.frameDiv} />;
};

export default FrameComponent;
