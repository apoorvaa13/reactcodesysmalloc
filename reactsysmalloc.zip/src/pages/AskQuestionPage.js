import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./AskQuestionPage.module.css";

const AskQuestionPage = () => {
  const navigate = useNavigate();

  const onQuestionsClick = useCallback(() => {
    navigate("/all-questions-page");
  }, [navigate]);

  const onUsersClick = useCallback(() => {
    navigate("/all-users-page");
  }, [navigate]);

  const onRectangleButtonClick = useCallback(() => {
    navigate("/users-page");
  }, [navigate]);

  const onSysMallocText1Click = useCallback(() => {
    navigate("/users-page");
  }, [navigate]);

  const onLogoutClick = useCallback(() => {
    // Please sync "Home Page" to the project
  }, []);

  const onScreenshot202302241556232Click = useCallback(() => {
    navigate("/users-page");
  }, [navigate]);

  const onUsernameClick = useCallback(() => {
    navigate("/user-profile-page");
  }, [navigate]);

  return (
    <div className={styles.askQuestionPage}>
      <div className={styles.frameParent}>
        <div className={styles.frameGroup}>
          <div className={styles.iconFacebookV1Parent}>
            <img
              className={styles.iconFacebookV1}
              alt=""
              src="/-icon-facebook-v1.svg"
            />
            <img
              className={styles.iconTwitter}
              alt=""
              src="/-icon-twitter1.svg"
            />
            <img
              className={styles.iconInstagram}
              alt=""
              src="/-icon-instagram1.svg"
            />
            <img
              className={styles.iconLinkedin}
              alt=""
              src="/-icon-linkedin1.svg"
            />
          </div>
          <div className={styles.siteDesignlogo}>
            site design/logo © 2023 #FFFFFF
          </div>
        </div>
        <div className={styles.sysmalloc}>SysMalloc</div>
        <img
          className={styles.screenshot202302241556231Icon}
          alt=""
          src="/screenshot-20230224-155623-1@2x.png"
        />
      </div>
      <div className={styles.questionsParent}>
        <button className={styles.questions} onClick={onQuestionsClick}>
          Questions
        </button>
        <button className={styles.users} onClick={onUsersClick}>
          Users
        </button>
      </div>
      <div className={styles.askAPublicQuestionWrapper}>
        <div className={styles.askAPublic}>Ask a Public Question</div>
      </div>
      <input className={styles.askQuestionPageChild} type="text" />
      <input className={styles.askQuestionPageItem} type="text" />
      <input className={styles.askQuestionPageInner} type="text" />
      <div className={styles.title}>Title</div>
      <div className={styles.tags}>Tags</div>
      <div className={styles.specifyTheDetails}>
        Specify the details of your problem
      </div>
      <div className={styles.beSpecificAnd}>
        Be specific and imagine you are asking question to another person
      </div>
      <div className={styles.introduceTheProblem}>
        Introduce the problem and expand on the basis of the title specified
        above
      </div>
      <div className={styles.addUpto5}>
        Add upto 5 tags to specify what your question is about
      </div>
      <div className={styles.div}>*</div>
      <div className={styles.div1}>*</div>
      <div className={styles.div2}>*</div>
      <div className={styles.rectangleParent}>
        <button
          className={styles.frameChild}
          onClick={onRectangleButtonClick}
        />
        <div className={styles.postYourQuestion}>Post your Question</div>
      </div>
      <div className={styles.rectangleGroup}>
        <button className={styles.frameItem} />
        <div className={styles.uploadImage}>upload image</div>
        <img
          className={styles.materialSymbolscloudUploadIcon}
          alt=""
          src="/materialsymbolscloudupload.svg"
        />
      </div>
      <div className={styles.sysmallocParent}>
        <div className={styles.sysmalloc1} onClick={onSysMallocText1Click}>
          SysMalloc
        </div>
        <textarea className={styles.frameInner} />
        <button className={styles.logout} onClick={onLogoutClick}>
          logout
        </button>
        <button
          className={styles.screenshot202302241556232}
          onClick={onScreenshot202302241556232Click}
        />
        <div className={styles.usernameParent}>
          <button className={styles.username} onClick={onUsernameClick}>
            Username
          </button>
          <img className={styles.vectorIcon} alt="" src="/vector.svg" />
        </div>
      </div>
    </div>
  );
};

export default AskQuestionPage;
