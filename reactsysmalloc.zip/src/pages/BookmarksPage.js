import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./BookmarksPage.module.css";

const BookmarksPage = () => {
  const navigate = useNavigate();

  const onQuestionsClick = useCallback(() => {
    navigate("/all-questions-page");
  }, [navigate]);

  const onUsersClick = useCallback(() => {
    navigate("/all-users-page");
  }, [navigate]);

  const onRectangleClick = useCallback(() => {
    const anchor = document.querySelector("[data-scroll-to='bookmarksText']");
    if (anchor) {
      anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }, []);

  const onRectangle1Click = useCallback(() => {
    const anchor = document.querySelector("[data-scroll-to='bookmarksText']");
    if (anchor) {
      anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }, []);

  const onRectangle2Click = useCallback(() => {
    navigate("/followers-page");
  }, [navigate]);

  const onRectangle3Click = useCallback(() => {
    navigate("/following-page");
  }, [navigate]);

  const onRectangle5Click = useCallback(() => {
    navigate("/edit-profile-page");
  }, [navigate]);

  const onRectangle6Click = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const onMongoDBDeletesAClick = useCallback(() => {
    navigate("/particular-question-page");
  }, [navigate]);

  const onSysMallocText1Click = useCallback(() => {
    navigate("/users-page");
  }, [navigate]);

  const onLogoutClick = useCallback(() => {
    // Please sync "Home Page" to the project
  }, []);

  const onScreenshot202302241556232Click = useCallback(() => {
    navigate("/users-page");
  }, [navigate]);

  const onUsernameClick = useCallback(() => {
    navigate("/user-profile-page");
  }, [navigate]);

  return (
    <div className={styles.bookmarksPage}>
      <div className={styles.frameParent}>
        <div className={styles.frameGroup}>
          <div className={styles.iconFacebookV1Parent}>
            <img
              className={styles.iconFacebookV1}
              alt=""
              src="/-icon-facebook-v1.svg"
            />
            <img
              className={styles.iconTwitter}
              alt=""
              src="/-icon-twitter.svg"
            />
            <img
              className={styles.iconInstagram}
              alt=""
              src="/-icon-instagram.svg"
            />
            <img
              className={styles.iconLinkedin}
              alt=""
              src="/-icon-linkedin.svg"
            />
          </div>
          <div className={styles.siteDesignlogo}>
            site design/logo © 2023 #FFFFFF
          </div>
        </div>
        <div className={styles.sysmalloc}>SysMalloc</div>
        <img
          className={styles.screenshot202302241556231Icon}
          alt=""
          src="/screenshot-20230224-155623-1@2x.png"
        />
      </div>
      <div className={styles.questionsParent}>
        <button className={styles.questions} onClick={onQuestionsClick}>
          Questions
        </button>
        <button className={styles.users} onClick={onUsersClick}>
          Users
        </button>
      </div>
      <div className={styles.bookmarks} data-scroll-to="bookmarksText">
        Bookmarks
      </div>
      <div className={styles.rectangleParent}>
        <div className={styles.frameChild} onClick={onRectangleClick} />
        <div className={styles.frameItem} onClick={onRectangle1Click} />
        <button className={styles.newest}>Newest</button>
        <button className={styles.score}>Score</button>
      </div>
      <div className={styles.reputation0Parent}>
        <div className={styles.reputation0}>Reputation: 0</div>
        <div className={styles.username}>Username</div>
        <img className={styles.image1Icon} alt="" src="/image-1@2x.png" />
        <div className={styles.rectangleGroup}>
          <div className={styles.frameInner} onClick={onRectangle2Click} />
          <button className={styles.followers}>Followers</button>
        </div>
        <div className={styles.rectangleContainer}>
          <div className={styles.rectangleDiv} onClick={onRectangle3Click} />
          <button className={styles.following}>Following</button>
        </div>
        <div className={styles.frameDiv}>
          <div className={styles.frameChild1} />
          <button className={styles.feed}>Feed</button>
        </div>
        <div className={styles.rectangleParent1}>
          <div className={styles.frameChild2} onClick={onRectangle5Click} />
          <button className={styles.editProfile}>Edit Profile</button>
          <img className={styles.mdipencilIcon} alt="" src="/mdipencil.svg" />
        </div>
        <img className={styles.vectorIcon} alt="" src="/vector2.svg" />
        <div className={styles.rectangleParent2}>
          <div className={styles.frameChild3} onClick={onRectangle6Click} />
          <button className={styles.bookmarks1}>Bookmarks</button>
        </div>
        <div className={styles.india}>India</div>
      </div>
      <div className={styles.frameContainer}>
        <div className={styles.answersParent}>
          <div className={styles.answers}>0 answers</div>
          <div className={styles.views}>9 views</div>
          <div className={styles.votes}>0 votes</div>
        </div>
        <div className={styles.iHaveTried}>
          I have tried all the possible solutions online but none of them seems
          to work.I want to auto delete a record in mongodb after a hour of
          creation. For this i am using below code but it...
        </div>
        <button className={styles.receivingAFs}>
          Receiving a FS and path error when trying to use SendGrid
        </button>
        <div className={styles.rectangleParent3}>
          <div className={styles.frameChild4} />
          <div className={styles.mongodb}>mongodb</div>
        </div>
        <div className={styles.rectangleParent4}>
          <div className={styles.frameChild5} />
          <div className={styles.reactjs}>reactjs</div>
        </div>
        <div className={styles.rectangleParent5}>
          <div className={styles.frameChild6} />
          <div className={styles.nodejs}>node.js</div>
        </div>
        <div className={styles.ransomenote}>ransomenote</div>
        <div className={styles.div}>395</div>
        <div className={styles.asked5Hours}>asked 5 hours ago</div>
      </div>
      <div className={styles.frameParent1}>
        <div className={styles.answersParent}>
          <div className={styles.answers}>0 answers</div>
          <div className={styles.views}>8 views</div>
          <div className={styles.votes}>0 votes</div>
        </div>
        <div className={styles.iHaveTried}>
          I have tried all the possible solutions online but none of them seems
          to work.I want to auto delete a record in mongodb after a hour of
          creation. For this i am using below code but it...
        </div>
        <div
          className={styles.mongodbDeletesA}
          onClick={onMongoDBDeletesAClick}
        >
          MongoDB deletes a record way before provided expiry time
        </div>
        <div className={styles.rectangleParent6}>
          <div className={styles.frameChild7} />
          <div className={styles.mongodbAtlas}>mongodb-atlas</div>
        </div>
        <div className={styles.rectangleParent7}>
          <div className={styles.frameChild8} />
          <div className={styles.reactjs}>mongogose</div>
        </div>
        <div className={styles.rectangleParent5}>
          <div className={styles.frameChild9} />
          <div className={styles.nodejs}>mongodb</div>
        </div>
        <div className={styles.franky11}>Franky 11</div>
        <div className={styles.div1}>41</div>
        <div className={styles.asked5Hours}>asked 28 mins ago</div>
      </div>
      <div className={styles.frameParent2}>
        <div className={styles.answersParent}>
          <div className={styles.answer}>1 answer</div>
          <div className={styles.votes}>0 votes</div>
        </div>
        <div className={styles.iHaveTried}>
          I have tried all the possible solutions online but none of them seems
          to work.I want to auto
        </div>
        <div className={styles.mongodbGetChild}>MongoDb get child data</div>
        <div className={styles.rectangleParent6}>
          <div className={styles.frameChild7} />
          <div className={styles.mongodbAtlas}>mongodb-atlas</div>
        </div>
        <div className={styles.rectangleParent7}>
          <div className={styles.frameChild8} />
          <div className={styles.reactjs}>mongogose</div>
        </div>
        <div className={styles.rectangleParent5}>
          <div className={styles.frameChild9} />
          <div className={styles.nodejs}>mongodb</div>
        </div>
        <div className={styles.franky11}>Franky 11</div>
        <div className={styles.div1}>41</div>
        <div className={styles.asked5Hours}>asked 28 mins ago</div>
      </div>
      <div className={styles.sysmallocParent}>
        <div className={styles.sysmalloc1} onClick={onSysMallocText1Click}>
          SysMalloc
        </div>
        <input className={styles.frameInput} type="text" />
        <button className={styles.logout} onClick={onLogoutClick}>
          logout
        </button>
        <button
          className={styles.screenshot202302241556232}
          onClick={onScreenshot202302241556232Click}
        />
        <div className={styles.usernameParent}>
          <button className={styles.username1} onClick={onUsernameClick}>
            Username
          </button>
          <img className={styles.vectorIcon1} alt="" src="/vector.svg" />
        </div>
      </div>
    </div>
  );
};

export default BookmarksPage;
