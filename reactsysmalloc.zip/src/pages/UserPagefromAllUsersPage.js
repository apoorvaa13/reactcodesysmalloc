import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./UserPagefromAllUsersPage.module.css";

const UserPagefromAllUsersPage = () => {
  const navigate = useNavigate();

  const onQuestionsClick = useCallback(() => {
    navigate("/all-questions-page");
  }, [navigate]);

  const onUsersClick = useCallback(() => {
    navigate("/all-users-page");
  }, [navigate]);

  const onRectangleClick = useCallback(() => {
    navigate("/user-pagefrom-all-users-pagebefore-following");
  }, [navigate]);

  const onRectangle1Click = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const onRectangle6Click = useCallback(() => {
    const anchor = document.querySelector("[data-scroll-to='questionsText']");
    if (anchor) {
      anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }, []);

  const onRectangle7Click = useCallback(() => {
    const anchor = document.querySelector("[data-scroll-to='questionsText']");
    if (anchor) {
      anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }, []);

  const onSysMallocText1Click = useCallback(() => {
    navigate("/users-page");
  }, [navigate]);

  const onLogoutClick = useCallback(() => {
    // Please sync "Home Page" to the project
  }, []);

  const onScreenshot202302241556232Click = useCallback(() => {
    navigate("/users-page");
  }, [navigate]);

  const onUsernameClick = useCallback(() => {
    navigate("/user-profile-page");
  }, [navigate]);

  return (
    <div className={styles.userPagefromAllUsersPage}>
      <div className={styles.frameParent}>
        <div className={styles.frameGroup}>
          <div className={styles.iconFacebookV1Parent}>
            <img
              className={styles.iconFacebookV1}
              alt=""
              src="/-icon-facebook-v1.svg"
            />
            <img
              className={styles.iconTwitter}
              alt=""
              src="/-icon-twitter4.svg"
            />
            <img
              className={styles.iconInstagram}
              alt=""
              src="/-icon-instagram.svg"
            />
            <img
              className={styles.iconLinkedin}
              alt=""
              src="/-icon-linkedin.svg"
            />
          </div>
          <div className={styles.siteDesignlogo}>
            site design/logo © 2023 #FFFFFF
          </div>
        </div>
        <div className={styles.sysmalloc}>SysMalloc</div>
        <img
          className={styles.screenshot202302241556231Icon}
          alt=""
          src="/screenshot-20230224-155623-1@2x.png"
        />
      </div>
      <div className={styles.questionsParent}>
        <button className={styles.questions} onClick={onQuestionsClick}>
          Questions
        </button>
        <button className={styles.users} onClick={onUsersClick}>
          Users
        </button>
      </div>
      <div className={styles.reputation6776Parent}>
        <div className={styles.reputation6776}>Reputation: 6,776</div>
        <div className={styles.mozway}>Mozway</div>
        <img className={styles.image1Icon} alt="" src="/image-1@2x.png" />
        <div className={styles.followingWrapper}>
          <button className={styles.following}>Following</button>
        </div>
        <div className={styles.rectangleParent}>
          <div className={styles.frameChild} onClick={onRectangleClick} />
          <button className={styles.unfollow}>Unfollow</button>
        </div>
        <img
          className={styles.noto1stPlaceMedalIcon}
          alt=""
          src="/noto1stplacemedal.svg"
        />
        <div className={styles.rectangleGroup}>
          <div className={styles.frameItem} onClick={onRectangle1Click} />
          <button className={styles.bookmarks}>Bookmarks</button>
        </div>
        <div className={styles.mareTranquillitatis}>Mare Tranquillitatis</div>
      </div>
      <div className={styles.rectangleContainer}>
        <div className={styles.frameInner} />
        <div className={styles.div}>7,809</div>
        <div className={styles.following1}>Following:</div>
        <div className={styles.followers}>{`Followers: `}</div>
        <div className={styles.upvotes}>{`Upvotes: `}</div>
        <div className={styles.div1}>3</div>
        <div className={styles.div2}>7,809</div>
        <div className={styles.div3}>8,927</div>
        <div className={styles.div4}>1,033</div>
        <div className={styles.answers}>Answers:</div>
        <div className={styles.downvotes}>Downvotes:</div>
        <div className={styles.questions1}>{`Questions: `}</div>
        <div className={styles.div5}>7,810</div>
      </div>
      <div className={styles.stats}>Stats</div>
      <div className={styles.frameDiv}>
        <div className={styles.rectangleDiv} />
        <button className={styles.followers1}>Followers</button>
        <button className={styles.frameButton} />
        <div className={styles.rectangleParent1}>
          <div className={styles.frameChild1} />
          <button className={styles.feed}>Feed</button>
        </div>
        <div className={styles.rectangleParent2}>
          <div className={styles.frameChild2} />
          <button className={styles.following}>Following</button>
        </div>
      </div>
      <div className={styles.questionsGroup}>
        <div className={styles.questions2} data-scroll-to="questionsText">
          Questions
        </div>
        <div className={styles.rectangleParent3}>
          <div className={styles.frameChild3} onClick={onRectangle6Click} />
          <div className={styles.frameChild4} onClick={onRectangle7Click} />
          <button className={styles.newest}>Newest</button>
          <button className={styles.score}>Score</button>
        </div>
      </div>
      <div className={styles.frameContainer}>
        <div className={styles.answerParent}>
          <div className={styles.answer}>1 answer</div>
          <div className={styles.views}>12 views</div>
          <div className={styles.votes}>0 votes</div>
        </div>
        <div
          className={styles.inYii2I}
        >{`In Yii2, I try to get another field data (which inside a Mongo collection) from a table (DB active record) in MySQL table. My summary table/model looks like this. 'merchant_id' =>...`}</div>
        <button className={styles.howToGet}>
          How to get Mongodb collection data from a table in MySql
        </button>
        <div className={styles.rectangleParent4}>
          <div className={styles.frameChild5} />
          <div className={styles.activerecord}>activerecord</div>
        </div>
        <div className={styles.rectangleParent5}>
          <div className={styles.frameChild6} />
          <div className={styles.mysql}>mysql</div>
        </div>
        <div className={styles.rectangleParent6}>
          <div className={styles.frameChild7} />
          <div className={styles.mongodb}>mongodb</div>
        </div>
        <div className={styles.mozway1}>Mozway</div>
        <div className={styles.div6}>6,776</div>
        <div className={styles.asked4Hours}>asked 4 hours ago</div>
      </div>
      <div className={styles.frameParent1}>
        <div className={styles.answerParent}>
          <div className={styles.answer}>1 answer</div>
          <div className={styles.views1}>16 views</div>
          <div className={styles.votes}>0 votes</div>
        </div>
        <div className={styles.inYii2I}>
          I have tried all the possible solutions online but none of them seems
          to work.I want to auto delete a record in mongodb after a hour of
          creation. For this i am using below code but it...
        </div>
        <div className={styles.mongodbGetChild}>MongoDb get child data</div>
        <div className={styles.rectangleParent7}>
          <div className={styles.frameChild8} />
          <div className={styles.mongodbAtlas}>mongodb-atlas</div>
        </div>
        <div className={styles.rectangleParent8}>
          <div className={styles.frameChild9} />
          <div className={styles.mysql}>mongogose</div>
        </div>
        <div className={styles.rectangleParent6}>
          <div className={styles.frameChild7} />
          <div className={styles.mongodb}>mongodb</div>
        </div>
        <div className={styles.franky11}>Franky 11</div>
        <div className={styles.div7}>41</div>
        <div className={styles.asked4Hours}>asked 28 mins ago</div>
      </div>
      <div className={styles.sysmallocParent}>
        <div className={styles.sysmalloc1} onClick={onSysMallocText1Click}>
          SysMalloc
        </div>
        <input className={styles.frameInput} type="text" />
        <button className={styles.logout} onClick={onLogoutClick}>
          logout
        </button>
        <button
          className={styles.screenshot202302241556232}
          onClick={onScreenshot202302241556232Click}
        />
        <div className={styles.usernameParent}>
          <button className={styles.username} onClick={onUsernameClick}>
            Username
          </button>
          <img className={styles.vectorIcon} alt="" src="/vector.svg" />
        </div>
      </div>
    </div>
  );
};

export default UserPagefromAllUsersPage;
