import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./UsersPage.module.css";

const UsersPage = () => {
  const navigate = useNavigate();

  const onQuestionsClick = useCallback(() => {
    navigate("/all-questions-page");
  }, [navigate]);

  const onUsersClick = useCallback(() => {
    navigate("/all-users-page");
  }, [navigate]);

  const onRectangleClick = useCallback(() => {
    const anchor = document.querySelector(
      "[data-scroll-to='topQuestionsText']"
    );
    if (anchor) {
      anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }, []);

  const onRectangleButtonClick = useCallback(() => {
    const anchor = document.querySelector(
      "[data-scroll-to='topQuestionsText']"
    );
    if (anchor) {
      anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }, []);

  const onRectangleButton1Click = useCallback(() => {
    const anchor = document.querySelector(
      "[data-scroll-to='topQuestionsText']"
    );
    if (anchor) {
      anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }, []);

  const onRectangleButton2Click = useCallback(() => {
    navigate("/ask-question-page");
  }, [navigate]);

  const onAskQuestionClick = useCallback(() => {
    navigate("/ask-question-page");
  }, [navigate]);

  const onHowToGetClick = useCallback(() => {
    navigate("/particular-question-page");
  }, [navigate]);

  const onLogoutClick = useCallback(() => {
    // Please sync "Home Page" to the project
  }, []);

  const onUsernameClick = useCallback(() => {
    navigate("/user-profile-page");
  }, [navigate]);

  return (
    <div className={styles.usersPage}>
      <div className={styles.frameParent}>
        <div className={styles.frameGroup}>
          <div className={styles.iconFacebookV1Parent}>
            <img
              className={styles.iconFacebookV1}
              alt=""
              src="/-icon-facebook-v1.svg"
            />
            <img
              className={styles.iconTwitter}
              alt=""
              src="/-icon-twitter.svg"
            />
            <img
              className={styles.iconInstagram}
              alt=""
              src="/-icon-instagram.svg"
            />
            <img
              className={styles.iconLinkedin}
              alt=""
              src="/-icon-linkedin.svg"
            />
          </div>
          <div className={styles.siteDesignlogo}>
            site design/logo © 2023 #FFFFFF
          </div>
        </div>
        <div className={styles.sysmalloc}>SysMalloc</div>
        <img
          className={styles.screenshot202302241556231Icon}
          alt=""
          src="/screenshot-20230224-155623-1@2x.png"
        />
      </div>
      <div className={styles.questionsParent}>
        <button className={styles.questions} onClick={onQuestionsClick}>
          Questions
        </button>
        <button className={styles.users} onClick={onUsersClick}>
          Users
        </button>
      </div>
      <div className={styles.topQuestionsParent}>
        <div className={styles.topQuestions} data-scroll-to="topQuestionsText">
          Top Questions
        </div>
        <div className={styles.rectangleParent}>
          <div className={styles.frameChild} onClick={onRectangleClick} />
          <button className={styles.unanswered}>Unanswered</button>
          <button
            className={styles.frameItem}
            onClick={onRectangleButtonClick}
          />
          <button
            className={styles.frameInner}
            onClick={onRectangleButton1Click}
          />
          <button className={styles.newest}>Newest</button>
          <button className={styles.score}>Score</button>
        </div>
        <div className={styles.rectangleGroup}>
          <button
            className={styles.rectangleButton}
            onClick={onRectangleButton2Click}
          />
          <button className={styles.askQuestion} onClick={onAskQuestionClick}>
            Ask Question
          </button>
        </div>
        <div className={styles.questions1}>23,521,337 questions</div>
      </div>
      <div className={styles.frameContainer}>
        <div className={styles.answersParent}>
          <div className={styles.answers}>0 answers</div>
          <div className={styles.views}>8 views</div>
          <div className={styles.votes}>0 votes</div>
        </div>
        <div className={styles.iHaveTried}>
          I have tried all the possible solutions online but none of them seems
          to work.I want to auto delete a record in mongodb after a hour of
          creation. For this i am using below code but it...
        </div>
        <button className={styles.mongodbDeletesA}>
          MongoDB deletes a record way before provided expiry time
        </button>
        <div className={styles.rectangleContainer}>
          <div className={styles.rectangleDiv} />
          <div className={styles.mongodbAtlas}>mongodb-atlas</div>
        </div>
        <div className={styles.frameDiv}>
          <div className={styles.frameChild1} />
          <div className={styles.mongogose}>mongogose</div>
        </div>
        <div className={styles.rectangleParent1}>
          <div className={styles.frameChild2} />
          <div className={styles.mongodb}>mongodb</div>
        </div>
        <div className={styles.franky11}>Franky 11</div>
        <div className={styles.div}>41</div>
        <div className={styles.asked28Mins}>asked 28 mins ago</div>
      </div>
      <div className={styles.frameParent1}>
        <div className={styles.answersParent}>
          <div className={styles.answer}>1 answer</div>
          <div className={styles.views1}>12 views</div>
          <div className={styles.votes}>0 votes</div>
        </div>
        <div
          className={styles.iHaveTried}
        >{`In Yii2, I try to get another field data (which inside a Mongo collection) from a table (DB active record) in MySQL table. My summary table/model looks like this. 'merchant_id' =>...`}</div>
        <div className={styles.howToGet} onClick={onHowToGetClick}>
          How to get Mongodb collection data from a table in MySql
        </div>
        <div className={styles.rectangleParent2}>
          <div className={styles.frameChild3} />
          <div className={styles.activerecord}>activerecord</div>
        </div>
        <div className={styles.rectangleParent3}>
          <div className={styles.frameChild4} />
          <div className={styles.mongogose}>mysql</div>
        </div>
        <div className={styles.rectangleParent1}>
          <div className={styles.frameChild2} />
          <div className={styles.mongodb}>mongodb</div>
        </div>
        <div className={styles.prabowomurti}>PrabowoMurti</div>
        <div className={styles.div1}>1286</div>
        <div className={styles.asked28Mins}>asked 4 hours ago</div>
      </div>
      <div className={styles.frameParent2}>
        <div className={styles.answersParent}>
          <div className={styles.answers}>0 answers</div>
          <div className={styles.views}>9 views</div>
          <div className={styles.votes}>0 votes</div>
        </div>
        <div className={styles.iHaveTried}>
          I have tried all the possible solutions online but none of them seems
          to work.I want to auto delete a record in mongodb after a hour of
          creation. For this i am using below code but it...
        </div>
        <div className={styles.receivingAFs}>
          Receiving a FS and path error when trying to use SendGrid
        </div>
        <div className={styles.rectangleParent5}>
          <div className={styles.frameChild6} />
          <div className={styles.mongodb2}>mongodb</div>
        </div>
        <div className={styles.rectangleParent6}>
          <div className={styles.frameChild7} />
          <div className={styles.mongogose}>reactjs</div>
        </div>
        <div className={styles.rectangleParent1}>
          <div className={styles.frameChild8} />
          <div className={styles.mongodb}>node.js</div>
        </div>
        <div className={styles.ransomenote}>ransomenote</div>
        <div className={styles.div2}>395</div>
        <div className={styles.asked28Mins}>asked 5 hours ago</div>
      </div>
      <div className={styles.frameParent3}>
        <div className={styles.answersParent}>
          <div className={styles.answer}>1 answer</div>
          <div className={styles.views3}>16 views</div>
          <div className={styles.votes}>0 votes</div>
        </div>
        <div className={styles.iHaveTried}>
          I have tried all the possible solutions online but none of them seems
          to work.I want to auto delete a record in mongodb after a hour of
          creation. For this i am using below code but it...
        </div>
        <div className={styles.receivingAFs}>MongoDb get child data</div>
        <div className={styles.rectangleContainer}>
          <div className={styles.rectangleDiv} />
          <div className={styles.mongodbAtlas}>mongodb-atlas</div>
        </div>
        <div className={styles.frameDiv}>
          <div className={styles.frameChild1} />
          <div className={styles.mongogose}>mongogose</div>
        </div>
        <div className={styles.rectangleParent1}>
          <div className={styles.frameChild2} />
          <div className={styles.mongodb}>mongodb</div>
        </div>
        <div className={styles.franky11}>Franky 11</div>
        <div className={styles.div}>41</div>
        <div className={styles.asked28Mins}>asked 28 mins ago</div>
      </div>
      <div className={styles.sysmallocParent}>
        <div className={styles.sysmalloc1}>SysMalloc</div>
        <input className={styles.frameInput} type="text" />
        <button className={styles.logout} onClick={onLogoutClick}>
          logout
        </button>
        <button className={styles.screenshot202302241556232} />
        <div className={styles.usernameParent}>
          <button className={styles.username} onClick={onUsernameClick}>
            Username
          </button>
          <img className={styles.vectorIcon} alt="" src="/vector.svg" />
        </div>
      </div>
    </div>
  );
};

export default UsersPage;
